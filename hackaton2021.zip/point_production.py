import pygame



class Point_Production:
    def __init__(self, groupes = []):
        self.groupes = groupes
        self.capacite = 0

    def add_group(self, groupe):
        self.groupes.append(groupe)
        self.capacite = sum([groupe.capacite for groupe in self.groupes])