from typing import ChainMap
import pygame

class Groupe_Production:

    def __init__(self, capacite):
        self.capacite = capacite

    def set_capacite(self, capacite):
        self.capacite = capacite